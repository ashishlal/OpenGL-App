#import "objc_udt.h"
#import "udt.h"

@implementation OBJC_UDT

+(int)startup
{ 
	return UDT::startup();	
}

+(int)cleanup
{
	return UDT::cleanup();	
}

+(UDTSOCKET)socket:(int)af type:(int)type protocol:(int)protocol
{
	return UDT::socket(af, type, protocol);	
}

+(int)bind:(UDTSOCKET)u address:(const struct sockaddr*)name length:(int)namelen
{
	return UDT::bind(u, name, namelen);
}

+(int)bind:(UDTSOCKET)u socket:(UDTSOCKET)udpsock
{
	return UDT::bind(u, udpsock);
}

+(int)listen:(UDTSOCKET)u maxPending:(int)backlog
{
	return UDT::listen(u, backlog);
}

+(UDTSOCKET)accept:(UDTSOCKET)u address:(struct sockaddr*) addr length:(int*)addrlen
{
	return UDT::accept(u, addr, addrlen);
}

+(int)connect:(UDTSOCKET)u address:(const struct sockaddr*)name length:(int)namelen
{
	return UDT::connect(u, name, namelen);
}

+(int)close:(UDTSOCKET)u
{
	return UDT::close(u);
}

+(int)getpeername:(UDTSOCKET)u address:(struct sockaddr*)name length:(int*)namelen
{
	return UDT::getpeername(u, name, namelen);
}

+(int)getsockname:(UDTSOCKET)u address:(struct sockaddr*)name length:(int*)namelen
{
	return UDT::getsockname(u, name, namelen);
}

+(int)getsockopt:(UDTSOCKET)u level:(int)level optname:(SOCKOPT)optname optval:(void*)optval length:(int*)optlen
{
	return UDT::getsockopt(u, level, optname, optval, optlen);
}

+(int)setsockopt:(UDTSOCKET)u level:(int)level optname:(SOCKOPT)optname optval:(const void*)optval length:(int)optlen
{
	return UDT::setsockopt(u, level, optname, optval, optlen);
}

+(int)send:(UDTSOCKET)u buffer:(const char*) buf length:(int)len flags:(int)flags
{
	return UDT::send(u, buf, len, flags);
}

+(int)recv:(UDTSOCKET)u buffer:(char*)buf length:(int)len flags:(int)flags
{
	return UDT::recv(u, buf, len, flags);
}

+(int)sendmsg:(UDTSOCKET)u buffer:(const char*) buf length:(int)len ttl:(int)ttl inorder:(bool)inorder
{
	return UDT::sendmsg(u, buf, len, ttl, inorder);
}

+(int)sendmsg:(UDTSOCKET)u buffer:(const char*) buf length:(int)len
{
	return UDT::sendmsg(u, buf, len);
}

+(int)recvmsg:(UDTSOCKET)u buffer:(char*)buf length:(int)len
{
	return UDT::recvmsg(u, buf, len);
}

+(int64_t)sendfile:(UDTSOCKET)u stream:(std::fstream&)ifs offset:(int64_t)offset size:(int64_t)size block:(int)block
{
	return UDT::sendfile(u, ifs, offset, size, block);
}

+(int64_t)recvfile:(UDTSOCKET)u stream:(std::fstream&)ofs offset:(int64_t)offset size:(int64_t)size block:(int)block
{ 
	return UDT::recvfile(u, ofs, offset, size, block);
}

+(int)select:(int)nfds readfds:(UDSET*)readfds writefds:(UDSET*)writefds exceptfds:(UDSET*)exceptfds timeout:(const struct timeval*)timeout
{
	return UDT::select(nfds, readfds, writefds, exceptfds, timeout);
}

+(int)select:(UDSET*)readfds writefds:(UDSET*)writefds timeout:(const struct timeval*)timeout
{
	return UDT::select(0, readfds, writefds, NULL, timeout);
}

+(int)selectEx:(const std::vector<UDTSOCKET>&)fds readfds:(std::vector<UDTSOCKET>*)readfds writefds:(std::vector<UDTSOCKET>*)writefds exceptfds:(std::vector<UDTSOCKET>*)exceptfds msTimeOut:(int64_t)msTimeOut
{
	return UDT::selectEx(fds, readfds, writefds, exceptfds, msTimeOut);
}

+(ERRORINFO&)getlasterror
{
	return UDT::getlasterror();
}

+(int)perfmon:(UDTSOCKET)u perf:(TRACEINFO*)perf clear:(bool)clear
{
	return UDT::perfmon(u, perf, clear);
}

@end
