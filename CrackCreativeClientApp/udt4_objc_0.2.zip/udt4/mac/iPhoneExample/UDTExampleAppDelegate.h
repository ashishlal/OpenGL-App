//
//  UDTExampleAppDelegate.h
//  ObjCUDP
//
//  Created by Ben Reeves on 22/02/2010.
//  Copyright 2010 Ben Reeves. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UDTExampleAppDelegate : NSObject <UIApplicationDelegate>
{
	IBOutlet UITextView * serverText;
	IBOutlet UITextView * clientText;
	IBOutlet UILabel * serverStatus;
	IBOutlet UILabel * clientStatus;

}

-(IBAction)sendClicked:(id)sender;
-(void)startServer;

@end
