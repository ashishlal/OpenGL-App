//
//  UDTExampleAppDelegate.m
//  ObjCUDP
//
//  Created by Ben Reeves on 22/02/2010.
//  Copyright 2010 Ben Reeves. All rights reserved.
//

#include <arpa/inet.h>
#include <iostream>
#import "UDTExampleAppDelegate.h"
#import "objc_udt.h"

using namespace std;

@implementation UDTExampleAppDelegate

-(void)applicationDidFinishLaunching:(UIApplication *)application
{
	[clientText becomeFirstResponder];
	
	// startup the library
	[OBJC_UDT startup];
	
	[self performSelectorInBackground:@selector(startServer) withObject:nil];
}

-(IBAction)sendClicked:(id)sender
{
	
	//Create a new socket
	UDTSOCKET fhandle = [OBJC_UDT socket:AF_INET type:SOCK_STREAM protocol:0];

	sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(short(6576));
	if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0)
	{
		cout << "incorrect network address.\n";
		return;
	}
	memset(&(serv_addr.sin_zero), '\0', 8);

	
	[clientStatus performSelectorOnMainThread:@selector(setText:) withObject:@"Client Status: Connecting" waitUntilDone:NO];

	if (UDT::ERROR == [OBJC_UDT connect:fhandle address:(sockaddr*)&serv_addr length:sizeof(serv_addr)])
	{
		cout << "connect: " << [OBJC_UDT getlasterror].getErrorMessage() << endl;
		return;
	}
	
	const char * message = [clientText.text UTF8String];
	
	[clientStatus performSelectorOnMainThread:@selector(setText:) withObject:@"Client Status: Sending" waitUntilDone:NO];

	// send the Length
	int len = strlen(message);
	
	if (UDT::ERROR == [OBJC_UDT send:fhandle buffer:(char*)&len length:sizeof(int) flags:0])
	{
		cout << "send: " << [OBJC_UDT getlasterror].getErrorMessage() << endl;
		return;
	}
	
	if (UDT::ERROR ==  [OBJC_UDT send:fhandle buffer:message length:len flags:0])
	{
		cout << "send: " << [OBJC_UDT getlasterror].getErrorMessage() << endl;
		return;
	}
	
	[clientStatus performSelectorOnMainThread:@selector(setText:) withObject:@"Client Status: Sent" waitUntilDone:NO];

}

-(void)updateUIWithMessage:(NSString*)message
{
	serverText.text = message;
}

-(void)startServer
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
			
	UDTSOCKET serv = [OBJC_UDT socket:AF_INET type:SOCK_STREAM protocol:0];
	
	if (serv < 0) 
        printf("ERROR opening socket\n");
	
	sockaddr_in my_addr;
	bzero((char *) &my_addr, sizeof(my_addr));

	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(6576);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	
	//Bind the socket to the specified port
	if (UDT::ERROR == [OBJC_UDT bind:serv address:(sockaddr*)&my_addr length:sizeof(my_addr)])
	{
		cout << "bind: " << [OBJC_UDT getlasterror].getErrorMessage();
		return;
	}
		
	[serverStatus performSelectorOnMainThread:@selector(setText:) withObject:@"Server Status: Listening" waitUntilDone:NO];
		
	[OBJC_UDT listen:serv maxPending:10];
	
	int namelen;
	sockaddr_in their_addr;
	
	while (1)
	{
		UDTSOCKET recver = [OBJC_UDT accept:serv address:(sockaddr*)&their_addr length:&namelen];
		
		cout << "new connection: " << inet_ntoa(their_addr.sin_addr) << ":" << ntohs(their_addr.sin_port) << endl;
		
		int len = 0;
		if (UDT::ERROR == [OBJC_UDT recv:recver buffer:(char*)&len length:sizeof(int) flags:0])
		{
			cout << "recv:" << [OBJC_UDT getlasterror].getErrorMessage() << endl;
			return;
		}
		
		char message[len+1];
		if (UDT::ERROR ==  [OBJC_UDT recv:recver buffer:message length:len flags:0])
		{
			cout << "recv:" << [OBJC_UDT getlasterror].getErrorMessage() << endl;
			return;
		}
		
		message[len] = '\0';
				
		[self performSelectorOnMainThread:@selector(updateUIWithMessage:) withObject:[NSString stringWithFormat:@"%s", message] waitUntilDone:NO];
				
		[OBJC_UDT close:recver];
	}

	[OBJC_UDT close:serv];

	[pool drain];

}

@end
